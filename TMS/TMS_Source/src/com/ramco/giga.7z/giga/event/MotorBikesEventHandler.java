package com.ramco.giga.event;

public class MotorBikesEventHandler {

}
